package tn.andrewlacambra.androidintent;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

public class logoutsection extends AppCompatActivity {

    TextView displayName;
    Button btnLogout;
    ImageView newImage;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_logoutsection);

        displayName = findViewById(R.id.displayName);
        btnLogout = (Button) findViewById(R.id.btnLogout);
        newImage = findViewById(R.id.newImage);

        String name = getIntent().getStringExtra("NAME");
        String id = getIntent().getStringExtra("ID");
        String info;
        if (name.equals("Andrew Lacambra")){
            info ="ID No.: " + id + "\n Name: " + name;
            displayName.setText(info);
            newImage.setImageResource(R.drawable.andrew);
        }else if (name.equals("Cristian Paul C. Agustin")){
            info ="ID No.: " + id+ "\n Name: " + name;
            displayName.setText(info);
            newImage.setImageResource(R.drawable.cristian);
        }else if (name.equals("Jan Christian Yuri G. Ibuos")) {
            info ="ID No.: " + id + "\n Name: " + name;
            displayName.setText(info);
            newImage.setImageResource(R.drawable.jan);
         }else if (name.equals("Mary Rose P. Nosis")) {
            info ="ID No.: " + id + "\n Name: " + name;
            displayName.setText(info);
            newImage.setImageResource(R.drawable.mary);
        }else{
            info ="ID No.: " + id + "\n Name: " + name;
            displayName.setText(info);

        }

        btnLogout.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intentL = new Intent(logoutsection.this, MainActivity.class );
                startActivity(intentL);
                finish();
                Toast.makeText(logoutsection.this, "Successfully Logged Out", Toast.LENGTH_SHORT).show();
            }
        });
    }
}
