package tn.andrewlacambra.androidintent;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

public class MainActivity extends AppCompatActivity {

    EditText editUsername, editPassword;
    Button btnLogin;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        editUsername = findViewById(R.id.editUsername);
        editPassword = findViewById(R.id.editPassword);

        btnLogin = (Button) findViewById(R.id.btnLog);
        btnLogin.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (editUsername.getText().toString().equals("Andrew") && editPassword.getText().toString().equals("Lacambra")){
                    String name = "Andrew Lacambra", id = "20190697";
                    Intent intent = new Intent(MainActivity.this, logoutsection.class);
                    intent.putExtra("NAME", name);
                    intent.putExtra("ID", id);
                    startActivity(intent);
                    Toast.makeText(MainActivity.this, "LogIn Successfully", Toast.LENGTH_SHORT).show();
                }else if (editUsername.getText().toString().equals("Paul") && editPassword.getText().toString().equals("Agustin")){
                    String name = "Cristian Paul C. Agustin", id = "20191468";
                    Intent intent = new Intent(MainActivity.this, logoutsection.class);
                    intent.putExtra("NAME", name);
                    intent.putExtra("ID", id);
                    startActivity(intent);
                    Toast.makeText(MainActivity.this, "Login Successfully", Toast.LENGTH_SHORT).show();
                }else if (editUsername.getText().toString().equals("Jan") && editPassword.getText().toString().equals("Ibuos")){
                    String name = "Jan Christian Yuri G. Ibuos", id = "20193145";
                    Intent intent = new Intent(MainActivity.this, logoutsection.class);
                    intent.putExtra("NAME", name);
                    intent.putExtra("ID", id);
                    startActivity(intent);
                    Toast.makeText(MainActivity.this, "Login Successfully", Toast.LENGTH_SHORT).show();
                }else if (editUsername.getText().toString().equals("Mary") && editPassword.getText().toString().equals("Nosis")){
                    String name = "Mary Rose P. Nosis.", id = "20194399";
                    Intent intent = new Intent(MainActivity.this, logoutsection.class);
                    intent.putExtra("NAME", name);
                    intent.putExtra("ID", id);
                    startActivity(intent);
                    Toast.makeText(MainActivity.this, "Login Successfully", Toast.LENGTH_SHORT).show();
                }else{
                    Toast.makeText(MainActivity.this, "Login Failed!", Toast.LENGTH_SHORT).show();
                }
            }
        });
    }
}

